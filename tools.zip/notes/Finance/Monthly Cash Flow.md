# Monthly Cash Flow

Rent is due on the first business day. Hold two months of rent as a cash reserve. Use the weekly sales review to forecast payroll, beans, and utility costs before ordering new equipment.
