# Payroll Notes

Payroll is processed every second Friday. Staff submit shift corrections by noon Wednesday. Track paid training separately from regular service hours so the weekly sales review shows operating labour accurately.
