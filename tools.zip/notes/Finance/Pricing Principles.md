# Pricing Principles

Price drinks at about four times their ingredient cost, but check nearby competitors before changing the menu. Seasonal specials may use a smaller margin when they encourage repeat visits and social sharing.
