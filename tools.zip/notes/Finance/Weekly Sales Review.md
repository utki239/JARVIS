# Weekly Sales Review

Review revenue, average ticket, labour percentage, food cost, and waste every Monday. The target average ticket is ₹340 and labour should remain below 29% of weekly sales. The [[Inventory Count]] informs the waste line.
