# Wholesale Beans

Wholesale bean sales could help stabilize slow weekday revenue, but begin with three nearby offices only. Set a minimum order of two kilograms and confirm delivery capacity before offering subscriptions.
