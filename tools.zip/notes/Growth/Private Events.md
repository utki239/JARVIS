# Private Events

Private evening events work best on Sundays when normal trade is lower. Charge a room fee plus a food and beverage minimum, and require a signed agreement two weeks ahead. Check the [[Catering Menu]].
