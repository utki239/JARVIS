# Second Location Criteria

Consider a second location only after twelve profitable months, a dependable manager, and cash reserves equal to six months of combined fixed costs. The first shop must maintain quality without the owner covering daily shifts.
