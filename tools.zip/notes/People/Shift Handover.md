# Shift Handover

The outgoing lead writes low stock, customer issues, equipment problems, and pending catering orders in the handover notebook. The incoming lead reads it before taking the till. Use the [[Closing Checklist]] as the final prompt.
