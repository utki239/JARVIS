# Staff Schedule

Publish the schedule two weeks ahead on Sunday evening. Request availability changes by Thursday. Keep two trained openers and one trained closer on every busy day.
