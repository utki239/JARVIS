# Barista Training

New baristas complete three shadow shifts, learn the [[Morning Coffee Standards]], then make ten observed drinks. Encourage calm, specific feedback after each rush. Training is paid time and recorded in [[Payroll Notes]].
