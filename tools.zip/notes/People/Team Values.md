# Team Values

We are warm, precise, and unhurried even during a queue. Greet every customer, own mistakes quickly, and protect each other’s breaks. The goal is a neighbourhood room people want to return to.
