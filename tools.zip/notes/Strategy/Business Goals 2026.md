# Business Goals 2026

For 2026, grow weekday morning sales by 15%, keep average review rating above 4.7, train two shift leads, and build a three-month cash reserve. Do not chase growth that weakens the neighbourhood feel.
