# Rainy Day Plan

On rainy days, move the chalkboard under the awning, promote pre-order pickup, and set extra mats at the entrance. Expect delivery delays and keep a small buffer of pastries from the prior evening.
