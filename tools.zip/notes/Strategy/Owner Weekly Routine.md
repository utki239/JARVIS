# Owner Weekly Routine

Monday: review sales and inventory. Tuesday: supplier check-in. Wednesday: one-on-ones with staff. Thursday: marketing review. Friday: walk the floor during the morning rush. Keep one half-day clear for strategic work.
