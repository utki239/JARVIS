# Catering Menu

Catering orders require 48 hours notice and a 50% deposit. The standard offer is coffee boxes, pastries, fruit, and optional dairy-free milk. Write event time, contact, dietary needs, and delivery address in the handover notebook.
