# Morning Coffee Standards

Espresso is dialled in at opening and after every major weather change. The house recipe is 18 grams in and 36 grams out in 27 to 31 seconds. Steam milk to a silky texture, not foam. This is central to [[Barista Training]].
