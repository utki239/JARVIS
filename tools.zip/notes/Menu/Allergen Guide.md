# Allergen Guide

Oat milk may contain gluten and all pastries are made in a kitchen that handles nuts. Always check the current supplier label for a specific allergen question. Never promise an item is safe when unsure; offer packaged alternatives.
