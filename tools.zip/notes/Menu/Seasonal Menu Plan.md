# Seasonal Menu Plan

Plan the next seasonal menu six weeks early. Test two drinks, one pastry, and one non-coffee option with regulars before finalising. Check [[Pricing Principles]] and ask the supplier about ingredient lead times.
