# Supplier Delivery Routine

Beans arrive Tuesday and Friday before 9:00 from Northline Roasters. Milk and pastries come every morning except Sunday. Check invoices against quantities immediately and message the owner about substitutions. The [[Opening Checklist]] depends on this delivery.
