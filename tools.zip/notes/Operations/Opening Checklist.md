# Opening Checklist

Open the shop at 8:30. Turn on the espresso machine, check the pastry display, count the till, and set the sidewalk chalkboard. Review the bookings calendar before the first customer arrives. See [[Morning Coffee Standards]] and [[Supplier Delivery Routine]].
