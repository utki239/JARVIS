# Equipment Maintenance

Backflush the espresso machine each evening, clean grinder burrs every Friday, and schedule the quarterly boiler service in January, April, July, and October. Keep service invoices in the office drawer.
