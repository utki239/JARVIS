# Inventory Count

Every Monday after closing, count beans, milk, alternative milks, cups, lids, pastries, syrups, and cleaning supplies. Reorder when coffee beans fall below 12 kilograms. Compare actual waste with the [[Weekly Sales Review]].
