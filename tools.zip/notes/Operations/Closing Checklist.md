# Closing Checklist

At 6:00, wipe tables, reconcile the till, record waste, run the dishwasher, and lock the back door. Take the bin to the alley only after the final delivery pickup. Flag low stock for the [[Supplier Delivery Routine]].
