# Accessibility Notes

Keep the entry ramp clear, leave the front table movable for wheelchair access, and read menu details aloud when asked. Keep music low enough for normal conversation. The accessible restroom key stays behind the counter.
