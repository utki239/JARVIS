# Regulars Notes

Remember names only when customers offer them naturally. Priya likes an oat flat white; the Tuesday chess group needs the long table after 4 PM. Do not store personal contact details here; keep notes respectful and practical.
