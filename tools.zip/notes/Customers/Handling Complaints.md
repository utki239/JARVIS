# Handling Complaints

Listen without interrupting, thank the customer, apologize for the experience, and offer a replacement or refund when appropriate. Record recurring issues in the shift handover so the team can prevent repeats.
