# Neighbourhood Partnerships

Offer local studios and bookshops a reciprocal noticeboard spot and a small employee discount. Prioritize partners within a ten-minute walk. Track referrals in the [[Weekly Sales Review]].
