# Loyalty Card

The paper loyalty card gives one free standard drink after nine paid drinks. Stamp only after payment and do not combine a free drink with another discount. Mention it warmly at checkout, never as a hard sell.
