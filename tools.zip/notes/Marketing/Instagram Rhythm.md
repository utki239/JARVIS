# Instagram Rhythm

Post three times each week: a drink or pastry on Tuesday, a team or behind-the-scenes moment on Thursday, and a neighbourhood story on Saturday. Save customer reposts in a highlights folder. Link seasonal items to the [[Seasonal Menu Plan]].
