# Launch Event Ideas

For a new menu launch, host a Friday tasting between 5 and 7 PM with small samples and a local musician. Keep staffing light but add one floater for cleanup and questions. Promote through [[Instagram Rhythm]].
