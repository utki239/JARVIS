# Knowledge Galaxy

The project currently includes a generated 30-note small-business knowledge base because no notes-folder path was supplied.

## Run it

1. Let Ollama finish installing the configured model: `ollama run qwen3.5:9b`.
2. Build graph data after changing notes: `python build.py` (or `python build.py C:\path\to\your\notes`).
3. Start the local-only viewer: `python server.py`.
4. Open `http://127.0.0.1:4700`.

`config.json` is the only file to edit when moving the same chat code to another OpenAI-compatible brain. Change `base_url`, `model`, and `api_key` there.

The server exposes the static viewer, `GET /health`, and `POST /chat`. It never serves the project root, notes, or `config.json`.
